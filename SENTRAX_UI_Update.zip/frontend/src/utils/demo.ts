// Demo is an explicit mode, never a fallback for failed production authentication.
export const DEMO_MODE = import.meta.env.VITE_DEMO_MODE === 'true' ||
  (typeof window !== 'undefined' && window.location.hostname === 'shakyavinit.github.io');
export const assetUrl = (path: string) => `${import.meta.env.BASE_URL}${path.replace(/^\.\//, '').replace(/^\//, '')}`;
